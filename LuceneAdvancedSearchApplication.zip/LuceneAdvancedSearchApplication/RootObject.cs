﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LuceneAdvancedSearchApplication
{
    class RootObject
    {
        public List<passage> passages { get; set; }
        public int query_id { get; set; }
        public List<string> answers { get; set; }
        public string query_type { get; set; }
        public string query { get; set; }
    }
}
