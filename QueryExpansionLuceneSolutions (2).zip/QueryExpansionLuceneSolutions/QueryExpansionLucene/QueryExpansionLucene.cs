﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lucene.Net.Analysis; // for Analyser
using Lucene.Net.Documents; // for Document and Field
using Lucene.Net.Index; //for Index Writer
using Lucene.Net.Store; //for Directory
using Lucene.Net.Search; // for IndexSearcher
using Syn.WordNet;
using Lucene.Net.QueryParsers;  // for QueryParser

namespace QueryExpansionLucene
{
    class QueryExpansionLucene
    {

        Lucene.Net.Store.Directory luceneIndexDirectory;
        Lucene.Net.Analysis.Analyzer analyzer;
        Lucene.Net.Index.IndexWriter writer;
        IndexSearcher searcher;
        QueryParser parser;

        const Lucene.Net.Util.Version VERSION = Lucene.Net.Util.Version.LUCENE_30;
        const string TEXT_FN = "Text";

        public QueryExpansionLucene()
        {
            luceneIndexDirectory = null;
            writer = null;
            analyzer = new Lucene.Net.Analysis.SimpleAnalyzer();
            parser = new QueryParser(Lucene.Net.Util.Version.LUCENE_30, TEXT_FN, analyzer);
        }


        /// <summary>
        /// Creates the index at a given path
        /// </summary>
        /// <param name="indexPath">The pathname to create the index</param>
        public void CreateIndex(string indexPath)
        {
            luceneIndexDirectory = Lucene.Net.Store.FSDirectory.Open(indexPath);
            IndexWriter.MaxFieldLength mfl = new IndexWriter.MaxFieldLength(IndexWriter.DEFAULT_MAX_FIELD_LENGTH);
            writer = new Lucene.Net.Index.IndexWriter(luceneIndexDirectory, analyzer, true, mfl);
        }


        /// <summary>
        /// Indexes a given string into the index
        /// </summary>
        /// <param name="text">The text to index</param>
        public void IndexText(string text)
        {

            Lucene.Net.Documents.Field field = new Field(TEXT_FN, text, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.YES);
            Lucene.Net.Documents.Document doc = new Document();
            doc.Add(field);
            writer.AddDocument(doc);
        }


        /// <summary>
        /// Flushes the buffer and closes the index
        /// </summary>
        public void CleanUpIndexer()
        {
            writer.Optimize();
            writer.Flush(true, true, true);
            writer.Dispose();
        }


        /// <summary>
        /// Creates the searcher object
        /// </summary>
        public void CreateSearcher()
        {
            searcher = new IndexSearcher(luceneIndexDirectory);
        }

        /// <summary>
        /// Searches the index for the querytext and displays a ranked list of results to the screen
        /// </summary>
        /// <param name="querytext">The text to search the index</param>
        public void SearchAndDisplayResults(string querytext)
        {

            System.Console.WriteLine("Searching for " + querytext);
            querytext = querytext.ToLower();
            Query query = parser.Parse(querytext);

            TopDocs results = searcher.Search(query, 100);

            int rank = 0;
            foreach (ScoreDoc scoreDoc in results.ScoreDocs)
            {
                rank++;
                Lucene.Net.Documents.Document doc = searcher.Doc(scoreDoc.Doc);
                string myFieldValue = doc.Get(TEXT_FN).ToString();
                Console.WriteLine("Rank " + rank + " text " + myFieldValue);
            }

        }



        /// <summary>
        /// Closes the index after searching
        /// </summary>
        public void CleanUpSearcher()
        {
            searcher.Dispose();
        }

        // Activity 7
        /// <summary>
        /// Creates a Thesuaris of stems
        /// </summary>
        /// <returns>A a Thesuaris of stems in the form: <stem,list of words> </returns>
        public Dictionary<string, string[]> CreateThesaurus()
        {
            Dictionary<string, string[]> thesaurus = new Dictionary<string, string[]>();

            thesaurus.Add("walk", new[] { "walk", "walked", "walking" });
            thesaurus.Add("run", new[] { "run", "running" });
            thesaurus.Add("love", new[] { "love", "lovely", "loving" });
            return thesaurus;
        }

        // Activity 8
        /// <summary>
        /// Expands the query with terms in the thesaurus
        /// </summary>
        /// <param name="thesaurus">A thesaurus of stems and associated terms</param>
        /// <param name="query">a query to stem</param>
        /// <returns>the query expanded with words that share the stem</returns>
        public string GetExpandedQuery(Dictionary<string, string[]> thesaurus, string queryTerm)
        {
            string expandedQuery = "";
            if (thesaurus.ContainsKey(queryTerm))
            {
                string[] array = thesaurus[queryTerm];
                foreach (string a in array)
                {
                    expandedQuery += " " + a;
                }
            }
            return expandedQuery;   
        }

        // Activity 10
        /// <summary>
        /// Expands the query with terms in the thesaurus but weights the original term the highest
        /// </summary>
        /// <param name="thesaurus">A thesaurus of stems and associated terms</param>
        /// <param name="query">a query to stem</param>
        /// <returns>the query expanded with words that share the stem</returns>
        public string GetWeightedExpandedQuery(Dictionary<string, string[]> thesausus, string query)
        {
            string expandedQuery = "";
            if (thesausus.ContainsKey(query))
            {
                bool first = true;
                string[] array = thesausus[query];
                foreach (string a in array)
                {
                    expandedQuery += " " + a;
                    if (first)
                    {
                        expandedQuery += "^5";
                        first = false;
                    }
                }
            }
            return expandedQuery;
        }


        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello Lucene.Net");

            QueryExpansionLucene myLuceneApp = new QueryExpansionLucene();

            // source collection
            List<string> l = new List<string>();
            l.Add("All my loving");
            l.Add("Band on the run");
            l.Add("Born to run");
            l.Add("Can\'t stop loving you");
            l.Add("Can\'t stop running");
            l.Add("Long train running");
            l.Add("Love will tear us apart");
            l.Add("Love makes the world go round");
            l.Add("Lovely Rita");
            l.Add("These boots were made for walking");
            l.Add("Take a walk on the wild side");
            l.Add("Reverse Running");
            l.Add("Run to the hills");
            l.Add("Walk this way");
            l.Add("Walk on in");
            l.Add("Walk like a man");
            l.Add("Walking on sunshine");
            l.Add("We\'ve lost that loving feeling");
            l.Add("You\'ll never walk alone");



            // Index code
            string indexPath = @"c:\temp\Week10Index";
            myLuceneApp.CreateIndex(indexPath);
            System.Console.WriteLine("Adding Documents to Index");
            foreach (string s in l)
            {
                myLuceneApp.IndexText(s);
            }
            System.Console.WriteLine("All documents added.");
            myLuceneApp.CleanUpIndexer();

            // Searching Code
            myLuceneApp.CreateSearcher();

            // Activity 6
            myLuceneApp.SearchAndDisplayResults("walk");
            myLuceneApp.SearchAndDisplayResults("run");
            myLuceneApp.SearchAndDisplayResults("love");
            
            // Activity 9
            Dictionary<string, string[]>  thesaurus = myLuceneApp.CreateThesaurus();
            myLuceneApp.SearchAndDisplayResults(myLuceneApp.GetExpandedQuery(thesaurus, "walk"));
            myLuceneApp.SearchAndDisplayResults(myLuceneApp.GetExpandedQuery(thesaurus, "run"));
            myLuceneApp.SearchAndDisplayResults(myLuceneApp.GetExpandedQuery(thesaurus, "love"));

            // Activity 10
            myLuceneApp.SearchAndDisplayResults(myLuceneApp.GetWeightedExpandedQuery(thesaurus, "walk"));
            myLuceneApp.SearchAndDisplayResults(myLuceneApp.GetWeightedExpandedQuery(thesaurus, "run"));
            myLuceneApp.SearchAndDisplayResults(myLuceneApp.GetWeightedExpandedQuery(thesaurus, "love"));

            var directory = System.IO.Directory.GetCurrentDirectory();

            var wordNet = new WordNetEngine();


            Console.WriteLine("Loading database...");
            wordNet.LoadFromDirectory(directory);
            Console.WriteLine("Load completed.");
            //Console.WriteLine("below is just messing up head with wordnet" +
            //    "");
            string word = "ball";
            var synSetList = wordNet.GetSynSets(word);
            //var synSetList2 = wordNet.GetSynSets("ball",PartOfSpeech.Noun);
            //var synSetList3 = wordNet.GetSynSets("ball", PartOfSpeech.Verb);

            foreach (var item in synSetList)
            {
                Console.WriteLine(item);
            }
            List<string> listofword = getonlywords(synSetList,word);

            foreach (string item in listofword)
            {
                Console.WriteLine(item);
            }

            
            //Console.WriteLine("////////////////////////////////////////////////////////////////////////////////////");
            //foreach (var item in synSetList2)
            //{
            //    Console.WriteLine(item);
            //}
            //Console.WriteLine("////////////////////////////////////////////////////////////////////////////////////");
            //foreach (var item in synSetList3)
            //{
            //    Console.WriteLine(item);
            //}

            //Console.WriteLine("//////////////////////////////////////now words check//////////////////////////////////////////////");

            //string p = "{testis, testicle, orchis, ball, ballock, bollock, nut, egg}: one of the two male reproductive glands that produce spermatozoa and secrete androgens";
            //p = wordselector(p);
            //Console.WriteLine(p);

            Console.ReadLine();
            myLuceneApp.CleanUpSearcher();


        }
        
        public static List<string> getonlywords(List<SynSet> collection, string word)
        {
            word = word.ToLower();
            List<string> wordlist= new List<string>();
            List<string> finalwordlist = new List<string>();
            foreach (var item in collection)
            {
                string s = Convert.ToString(item);
                wordlist.Add(wordselector(s,word)); 
            }
            foreach (string item in wordlist)
            {
                string[] s = item.Split();
                foreach (string i in s)
                {
                    if((i.Length>1) && (i.ToLower())!=word )
                    {
                        finalwordlist.Add(i);
                    }
                }
            }
            
            return finalwordlist;
        }
        /// <summary>
        /// this will take a sentence and fetch only synonyms and related words to the query term
        /// </summary>
        /// <param name="item"></param>
        /// <param name="orignal_word"></param>
        /// <returns></returns>
        public static string wordselector(string item, string orignal_word)
        {
            string wordstring ="" ;
            bool controller= false;
            string[] seprator = new string[] { " ", ",",":",";" };
            string[] words = item.Split(seprator,StringSplitOptions.RemoveEmptyEntries);
            foreach (string a in words)
            {
                string c ="";
                string b = a;
                int countofstring = 0;
                countofstring = b.Length -1 ;
                if (b == "{" || b[0] == '{')
                {
                   b =  b.Remove(0, 1);
                    controller = true;
                    c = b;
                    int countofc = c.Length;
                    if (c[(countofc-1)] == '}')
                    {
                        c = c.Remove((countofc - 1), 1);
                    }
                }
                
                if (controller == true && (b!= orignal_word) && (c != orignal_word))
                {
                    if (b[(b.Length-1)] == '}')
                    {
                        wordstring += " " + b.Remove((b.Length - 1),1);
                        controller = false;
                    }
                    else
                    {
                        wordstring += " " + b;
                    }
                    

                }
                
                int countofstring1 = 0;
                countofstring1 = b.Length - 1;

                if (b == "}" || b[countofstring1] == '}')
                { 
                    
                    controller = false;
                }

            }
            return wordstring;
        }
    }
}
