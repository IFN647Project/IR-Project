﻿using System;
using System.IO;
using System.Collections.Generic;
using Syn.WordNet;

namespace QueryExpansionLucene
{
    class QueryExpansionLucene
    {

         
        static void Main(string[] args)
        {
            //*************MAIN IDEA************

            // TOKENIZE THE QUERY AND REMOVE THE STOP WORDS AND PASS IT TO WORDNET 
            // THE OUTPUT OF THE WORDNET WILL BE THE EXPANDED QUERY.

            // WORDNET AT THE MOMENT ONLY ACCEPTING SINGLE WORD BUT WE ARE GENERATING ARRAY OF WORDS....
            //HOPE FIXABLE.


            System.Console.WriteLine("stop words");

            // just a sample query with stop words 
            string testQuery = "hi i am very of off you've book fruit myself";
            //tokenize the query
            char[] delim = { ' ', '!', ',', ';', '-', '\'', '.' };
            string[] tokenQueries = testQuery.ToLower().Split(delim, StringSplitOptions.RemoveEmptyEntries);

            //Trying to replace the string in tokenQueries that matches with stop words 
            //by empty stiring and this is where i messed up
            singlepagebaseline.stopword stword = new singlepagebaseline.stopword();
            foreach( string wd in stword.returnstopwords())
            {
                foreach(string Tq in tokenQueries)
                {
                    string finalquery = Tq.Replace(wd, " ");
                    Console.WriteLine(finalquery);
                }
                
            }

            

       //**************** WORDNET STARTS FROM HERE***************



            var directory = System.IO.Directory.GetCurrentDirectory();

            var wordNet = new WordNetEngine();


            Console.WriteLine("Loading database...");
            wordNet.LoadFromDirectory(directory);
            Console.WriteLine("Load completed.");
            //Console.WriteLine("below is just messing up head with wordnet" +
            //    "");
            //string [] manyWords = { "furniture", "school", "book"};
           
           
            string word = "school";

            var synSetList = wordNet.GetSynSets(word);
            //var synSetList2 = wordNet.GetSynSets("ball",PartOfSpeech.Noun);
            //var synSetList3 = wordNet.GetSynSets("ball", PartOfSpeech.Verb);
          
              /*          foreach (var item in synSetList)
                        {
                            Console.WriteLine(item);
                        }*/
           

            List<string> listofword = getonlywords(synSetList,word);

                        foreach (string item in listofword)
                        {
                            Console.WriteLine(item);
                        }
                        

            

            Console.ReadLine();
            


        }
        
        public static List<string> getonlywords(List<SynSet> collection, string word)
        {
            word = word.ToLower();
            List<string> wordlist= new List<string>();
            List<string> finalwordlist = new List<string>();
            foreach (var item in collection)
            {
                string s = Convert.ToString(item);
                wordlist.Add(wordselector(s,word)); 
            }
            foreach (string item in wordlist)
            {
                string[] s = item.Split();
                foreach (string i in s)
                {
                    if((i.Length>1) && (i.ToLower())!=word )
                    {
                        finalwordlist.Add(i);
                    }
                }
            }
            
            return finalwordlist;
        }
        /// <summary>
        /// this will take a sentence and fetch only synonyms and related words to the query term
        /// </summary>
        /// <param name="item"></param>
        /// <param name="orignal_word"></param>
        /// <returns></returns>
 public static string wordselector(string item, string orignal_word)
 {
     string wordstring ="" ;
     bool controller= false;
     string[] seprator = new string[] { " ", ",",":",";"};
     string[] words = item.Split(seprator,StringSplitOptions.RemoveEmptyEntries);
     foreach (string a in words)
     {
         string c ="";
         string b = a;
         int countofstring = 0;
         countofstring = b.Length -1 ;
         if (b == "{" || b[0] == '{')
         {
            b =  b.Remove(0, 1);
             controller = true;
             c = b;
             int countofc = c.Length;
             if (c[(countofc-1)] == '}')
             {
                 c = c.Remove((countofc - 1), 1);
             }
         }

         if (controller == true && (b!= orignal_word) && (c != orignal_word))
         {
             if (b[(b.Length-1)] == '}')
             {
                 wordstring += " " + b.Remove((b.Length - 1),1);
                 controller = false;
             }
             else
             {
                 wordstring += " " + b;
             }


         }

         int countofstring1 = 0;
         countofstring1 = b.Length - 1;

         if (b == "}" || b[countofstring1] == '}')
         { 

             controller = false;
         }

     }
     return wordstring;
 }
}
}
