﻿namespace baseline
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.index_path = new System.Windows.Forms.Label();
            this.collection_path = new System.Windows.Forms.Label();
            this.index_save = new System.Windows.Forms.Button();
            this.collection_saved_path = new System.Windows.Forms.Button();
            this.create_index_button = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.SuspendLayout();
            // 
            // index_path
            // 
            this.index_path.AutoSize = true;
            this.index_path.Location = new System.Drawing.Point(99, 33);
            this.index_path.Name = "index_path";
            this.index_path.Size = new System.Drawing.Size(58, 13);
            this.index_path.TabIndex = 0;
            this.index_path.Text = "Index Path";
            this.index_path.Click += new System.EventHandler(this.label1_Click);
            // 
            // collection_path
            // 
            this.collection_path.AutoSize = true;
            this.collection_path.Location = new System.Drawing.Point(99, 72);
            this.collection_path.Name = "collection_path";
            this.collection_path.Size = new System.Drawing.Size(78, 13);
            this.collection_path.TabIndex = 1;
            this.collection_path.Text = "Collection Path";
            // 
            // index_save
            // 
            this.index_save.Location = new System.Drawing.Point(283, 23);
            this.index_save.Name = "index_save";
            this.index_save.Size = new System.Drawing.Size(53, 23);
            this.index_save.TabIndex = 2;
            this.index_save.Text = "Save";
            this.index_save.UseVisualStyleBackColor = true;
            this.index_save.Click += new System.EventHandler(this.index_save_Click);
            // 
            // collection_saved_path
            // 
            this.collection_saved_path.Location = new System.Drawing.Point(291, 72);
            this.collection_saved_path.Name = "collection_saved_path";
            this.collection_saved_path.Size = new System.Drawing.Size(53, 23);
            this.collection_saved_path.TabIndex = 3;
            this.collection_saved_path.Text = "Browse";
            this.collection_saved_path.UseVisualStyleBackColor = true;
            this.collection_saved_path.Click += new System.EventHandler(this.collection_saved_path_Click);
            // 
            // create_index_button
            // 
            this.create_index_button.Location = new System.Drawing.Point(291, 219);
            this.create_index_button.Name = "create_index_button";
            this.create_index_button.Size = new System.Drawing.Size(106, 39);
            this.create_index_button.TabIndex = 4;
            this.create_index_button.Text = "Create Index";
            this.create_index_button.UseVisualStyleBackColor = true;
            this.create_index_button.Click += new System.EventHandler(this.create_index_button_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "myOpenFileDialog";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.create_index_button);
            this.Controls.Add(this.collection_saved_path);
            this.Controls.Add(this.index_save);
            this.Controls.Add(this.collection_path);
            this.Controls.Add(this.index_path);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label index_path;
        private System.Windows.Forms.Label collection_path;
        private System.Windows.Forms.Button index_save;
        private System.Windows.Forms.Button collection_saved_path;
        private System.Windows.Forms.Button create_index_button;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
    }
}

