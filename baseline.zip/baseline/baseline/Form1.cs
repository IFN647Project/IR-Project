﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace baseline
{
    
    public partial class Form1 : Form
    {
        public string indexPath;
        Form2 f2 = new Form2();
        LuceneAdvancedSearchApplication myLuceneApp;
        string filePath;
        public Form1()
        {
            
            InitializeComponent();
            myLuceneApp = new LuceneAdvancedSearchApplication();
        }
        
         
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void index_save_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            index_path.Text = folderBrowserDialog1.SelectedPath;
            string addindex = "\\index";
            indexPath = folderBrowserDialog1.SelectedPath + addindex;
            f2.indexPath = indexPath;

        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {

        }

        private void create_index_button_Click(object sender, EventArgs e)
        {
            myLuceneApp.CreateIndex(indexPath);
            myLuceneApp.jsreader(filePath);
            myLuceneApp.CreateSearcher();

            Form2 f2 = new Form2();
            f2.Show();

            
        }

        private void collection_saved_path_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            collection_path.Text = openFileDialog1.FileName;
            filePath = openFileDialog1.FileName;
        }

        //////////////////////////////////////////// code of lucene//////////////
        
    }
}
