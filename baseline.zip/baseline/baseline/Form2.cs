﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace baseline
{
    public partial class Form2 : Form
    {
        LuceneAdvancedSearchApplication myLuceneApp;
        string tosearch;
        Form f1;
        public string indexPath { get; set; }
        List<string> result;
        public Form2()
        {
            InitializeComponent();
            myLuceneApp = new LuceneAdvancedSearchApplication();
            result = new List<string>();
            f1 = new Form1();
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void searchbutton_Click(object sender, EventArgs e)
        {
            
            
            result = myLuceneApp.SearchText(tosearch);

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            tosearch =  textBox1.Text;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.DataSource = result;
            myLuceneApp.CleanUpIndexer();

            myLuceneApp.CleanUpSearcher();
        }
    }
}
