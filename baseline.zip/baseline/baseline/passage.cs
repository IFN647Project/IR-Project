﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace baseline
{
    class passage
    {
        public string passage_text { get; set; }
        public string url { get; set; }
        public string is_selected { get; set; }
        public string passage_ID { get; set; }
    }
}
