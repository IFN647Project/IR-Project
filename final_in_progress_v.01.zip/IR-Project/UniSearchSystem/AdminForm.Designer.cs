﻿namespace UniSearchSystem
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdminForm));
            this.BrowseCollectionButton = new System.Windows.Forms.Button();
            this.BrowseCollectionLabel = new System.Windows.Forms.Label();
            this.CollectionPathOFD = new System.Windows.Forms.OpenFileDialog();
            this.collectionsTable = new System.Windows.Forms.TableLayoutPanel();
            this.index = new System.Windows.Forms.Button();
            this.close = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // BrowseCollectionButton
            // 
            this.BrowseCollectionButton.Location = new System.Drawing.Point(79, 30);
            this.BrowseCollectionButton.Name = "BrowseCollectionButton";
            this.BrowseCollectionButton.Size = new System.Drawing.Size(87, 23);
            this.BrowseCollectionButton.TabIndex = 0;
            this.BrowseCollectionButton.Text = "Add Collection";
            this.BrowseCollectionButton.UseVisualStyleBackColor = true;
            this.BrowseCollectionButton.Click += new System.EventHandler(this.BrowseCollectionButton_Click);
            // 
            // BrowseCollectionLabel
            // 
            this.BrowseCollectionLabel.AutoSize = true;
            this.BrowseCollectionLabel.Location = new System.Drawing.Point(183, 35);
            this.BrowseCollectionLabel.Name = "BrowseCollectionLabel";
            this.BrowseCollectionLabel.Size = new System.Drawing.Size(91, 13);
            this.BrowseCollectionLabel.TabIndex = 1;
            this.BrowseCollectionLabel.Text = "Browse Collection";
            this.BrowseCollectionLabel.Click += new System.EventHandler(this.BrowseCollectionLabel_Click);
            // 
            // CollectionPathOFD
            // 
            this.CollectionPathOFD.Filter = "json files (*.json)|*.json";
            this.CollectionPathOFD.FileOk += new System.ComponentModel.CancelEventHandler(this.CollectionPath_FileOk);
            // 
            // collectionsTable
            // 
            this.collectionsTable.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.collectionsTable.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.collectionsTable.ColumnCount = 3;
            this.collectionsTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 15F));
            this.collectionsTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 75F));
            this.collectionsTable.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 10F));
            this.collectionsTable.Location = new System.Drawing.Point(69, 71);
            this.collectionsTable.Name = "collectionsTable";
            this.collectionsTable.RowCount = 2;
            this.collectionsTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.collectionsTable.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 15F));
            this.collectionsTable.Size = new System.Drawing.Size(632, 213);
            this.collectionsTable.TabIndex = 2;
            this.collectionsTable.Paint += new System.Windows.Forms.PaintEventHandler(this.collectionsTable_Paint);
            this.collectionsTable.Controls.Add(new System.Windows.Forms.Label() { Text = "Collection" }, 0, 0);
            this.collectionsTable.Controls.Add(new System.Windows.Forms.Label() { Text = "Path" }, 1, 0);
            this.collectionsTable.Controls.Add(new System.Windows.Forms.Label() { Text = "Size" }, 2, 0);
            // 
            // index
            // 
            this.index.Location = new System.Drawing.Point(520, 387);
            this.index.Name = "index";
            this.index.Size = new System.Drawing.Size(105, 33);
            this.index.TabIndex = 3;
            this.index.Text = "Index";
            this.index.UseVisualStyleBackColor = true;
            this.index.Click += new System.EventHandler(this.index_Click);
            // 
            // close
            // 
            this.close.Location = new System.Drawing.Point(655, 387);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(105, 33);
            this.close.TabIndex = 4;
            this.close.Text = "close";
            this.close.UseVisualStyleBackColor = true;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // AdminForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.close);
            this.Controls.Add(this.index);
            this.Controls.Add(this.collectionsTable);
            this.Controls.Add(this.BrowseCollectionLabel);
            this.Controls.Add(this.BrowseCollectionButton);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "AdminForm";
            this.Text = "M.A.N.T Search (Admin View)";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button BrowseCollectionButton;
        private System.Windows.Forms.Label BrowseCollectionLabel;
        private System.Windows.Forms.OpenFileDialog CollectionPathOFD;
        private System.Windows.Forms.TableLayoutPanel collectionsTable;
        private System.Windows.Forms.Button index;
        private System.Windows.Forms.Button close;
    }
}