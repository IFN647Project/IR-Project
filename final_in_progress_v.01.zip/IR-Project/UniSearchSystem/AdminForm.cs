﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lucene.Net.Analysis;
using Lucene.Net.Analysis.Standard;

namespace UniSearchSystem
{
    public partial class AdminForm : Form
    {
        const Lucene.Net.Util.Version VERSION = Lucene.Net.Util.Version.LUCENE_30;
        const string TEXT_FN = "Text";

        string defaultSimpleIndexPath = @"C:\temp\simple_index";

        public AdminForm()
        {
            InitializeComponent();
        }

        private void BrowseCollectionButton_Click(object sender, EventArgs e)
        {
           
            try
            {
                if (CollectionPathOFD.ShowDialog() == DialogResult.OK);
                if (CollectionPathOFD.FileName != "")
                {

                    string fileName = CollectionPathOFD.SafeFileName;
                    string filePath = CollectionPathOFD.FileName;

                    BrowseCollectionLabel.Text = filePath;

                    Label fileNameLabel = new System.Windows.Forms.Label() { Text = fileName };
                    Label filePathLabel = new System.Windows.Forms.Label() { Text = filePath };

                    fileNameLabel.AutoSize = true;
                    filePathLabel.AutoSize = true;

                    collectionsTable.RowStyles.Add(new RowStyle(SizeType.Absolute, 15F));
                    collectionsTable.Controls.Add(fileNameLabel, 0, collectionsTable.RowCount - 1);
                    collectionsTable.Controls.Add(filePathLabel, 1, collectionsTable.RowCount - 1);
                    collectionsTable.RowCount++;
                }


                // add stream reader here

            }
            catch (SecurityException ex)
            {
                MessageBox.Show($"Security error.\n\nError message: {ex.Message}\n\n" +
                $"Details:\n\n{ex.StackTrace}");
            }
                
        }

        private void CollectionPath_FileOk(object sender, CancelEventArgs e)
        {
            

        }

        private void collectionsTable_Paint(object sender, PaintEventArgs e)
        {

        }

        private void close_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void index_Click(object sender, EventArgs e)
        {


            for (int i = 1; i < collectionsTable.RowCount - 1; i++)
            {
                string collectionName = collectionsTable.GetControlFromPosition(0, i).Text;
                string collectionPath = collectionsTable.GetControlFromPosition(1, i).Text;
                Console.WriteLine("select row: " + collectionPath);   //DELETE
                Console.ReadLine();     //DELETE    

                Analyzer standardAnalyzer = new StandardAnalyzer(VERSION);
                
                MantIndex simpleIndex = new MantIndex(standardAnalyzer);
                simpleIndex.CreateIndex(collectionPath, defaultSimpleIndexPath);
            }

        }

        private void BrowseCollectionLabel_Click(object sender, EventArgs e)
        {

        }
    }
}
