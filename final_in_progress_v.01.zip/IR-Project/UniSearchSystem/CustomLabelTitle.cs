﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UniSearchSystem
{
    class CustomLabelTitle : Label
    {
        public CustomLabelTitle()
        {
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.HighlightText;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Location = new System.Drawing.Point(22, 92);
            //this.Name = "Title";
            this.Size = new System.Drawing.Size(155, 20);
            this.TabIndex = 7;
            //this.Text = "Some Title";
            this.Click += new System.EventHandler(this.Title_Click);
        }

        private void Title_Click(object sender, EventArgs e)
        {
            
        }
    }
}
