﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lucene.Net.Analysis;
using Lucene.Net.Analysis.Standard;
using Lucene.Net.Search;
using Lucene.Net.Store;

namespace UniSearchSystem
{
    public partial class MANTForm : Form
    {

        const Lucene.Net.Util.Version VERSION = Lucene.Net.Util.Version.LUCENE_30;

        public MANTForm()
        {
            //test 3
            InitializeComponent();

            AdminForm adminForm = new AdminForm();
            adminForm.Show();
            adminForm.TopMost = true;

        }

        private void MANTForm_Load(object sender, EventArgs e)
        {
           
        }

        private void StandardAnalyzer_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void advancedOptionsPanel_Paint(object sender, PaintEventArgs e)
        {

        }

        private void searchButton_Click_1(object sender, EventArgs e)
        {
            string indexPath = null;
            Analyzer analyzer = null;

            if (WhiteSpaceAnalyzer.Checked == true)
            {
                indexPath = @"C:\temp\whitespace_index";
                analyzer = new WhitespaceAnalyzer();
            }
            else if (StopAnalyzer.Checked == true)
            {
                indexPath = @"C:\temp\stop_index";
                //analyzer = new StopAnalyzer();
            }
            else if (KeywordAnalyzer.Checked == true)
            {
                indexPath = @"C:\temp\keyword_index";
                analyzer = new KeywordAnalyzer();
            }
            else
            {
                indexPath = @"C:\temp\simple_index";
                analyzer = new StandardAnalyzer(VERSION);
            }

            string text = searchBox.Text.Trim();
            
            List<Dictionary<string, string>> searchResult = new List<Dictionary<string, string>>();
            MantSearch mantSearch = new MantSearch(indexPath, analyzer);
            if (text != "")
                searchResult = mantSearch.search(text);

            displayResults(searchResult);
        }

        private void displayResults(List<Dictionary<string, string>> results)
        {
            int counter = 1;
            foreach (var result in results)
            {
                CustomLabelTitle customLabelTitle = new CustomLabelTitle() { Text = "Some Text" };
                customLabelTitle.AutoSize = true;
                searchResultTable.Controls.Add(customLabelTitle, 0, counter-1);

                searchResultTable.RowCount++;
                if (counter %10 == 0)
                    break;
            }
        }

        private void Logo_Click(object sender, EventArgs e)
        {

        }

        private void searchBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void AdvancedOptions_Click(object sender, EventArgs e)
        {

        }
    }
}
