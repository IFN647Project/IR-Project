﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lucene.Net;
using Lucene.Net.Index;
using Lucene.Net.Analysis;
using System.IO;
using Newtonsoft.Json;
using Lucene.Net.Documents;

namespace UniSearchSystem
{
    class MantIndex
    {
        Lucene.Net.Store.Directory indexDirectory = null;
        Lucene.Net.Index.IndexWriter writer = null;
        Lucene.Net.Analysis.Analyzer analyzer = null;

        public MantIndex(Analyzer analyzer)
        {
            this.analyzer = analyzer;
        }
        public void CreateIndex(string collectionPath, string indexPath)
        {
            indexDirectory = Lucene.Net.Store.FSDirectory.Open(indexPath);

            IndexWriter.MaxFieldLength mfl = new IndexWriter.MaxFieldLength(IndexWriter.DEFAULT_MAX_FIELD_LENGTH);
            writer = new Lucene.Net.Index.IndexWriter(indexDirectory, analyzer, true, mfl);

            StreamReader streamReader = new StreamReader(collectionPath);
            JsonTextReader JTextreader = new JsonTextReader(streamReader);

            JTextreader.SupportMultipleContent = true;

            var serializer = new JsonSerializer();
            while (JTextreader.Read())
            {
                if (JTextreader.TokenType == JsonToken.StartObject)
                {
                    RootObject p = serializer.Deserialize<RootObject>(JTextreader);

                    foreach (var para in p.passages)
                    {
                        //  passage p_content = serializer.Deserialize<passage>(JTextreader);
                        string text = /*getUrlEndDocName(para.url) +*/ para.passage_text;
                        string url = para.url;

                        Field textField = new Field("text", text, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.YES);
                        Field urlField = new Field("url", text, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.YES);
                       
                        Document doc = new Document();
                        doc.Add(textField);
                        doc.Add(urlField);

                        writer.AddDocument(doc);
                    }

                }
            }

            writer.Optimize();
            writer.Flush(true, true, true);
            writer.Dispose();
        }

        public string getUrlEndDocName(string url)
        {
            string urlstring = url.TrimEnd('/');

            string urlEndDocName = "NULL";

            string[] urlArray;
            char[] seperator = { '/' };
            urlArray = urlstring.Split(seperator, StringSplitOptions.RemoveEmptyEntries);
            if (urlArray.Length > 2)
                urlEndDocName = urlArray[urlArray.Length - 1];
            
            return urlEndDocName;
        }
    }
}
