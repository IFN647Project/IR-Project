﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UniSearchSystem
{
    class CustomLabelUrl : Label
    {
        public CustomLabelUrl()
        {
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.HighlightText;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.ForeColor = System.Drawing.Color.LightGreen;
            //this.Location = new System.Drawing.Point(22, 92);
            //this.Name = "Title";
            //this.Size = new System.Drawing.Size(155, 5);
            //this.TabIndex = 7;
            //this.Text = "Some Title";
            this.Click += new System.EventHandler(this.Url_Click);
        }

        private void Url_Click(object sender, EventArgs e)
        {
            
        }
    }
}
