﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lucene.Net.Analysis;
using Lucene.Net.Documents;
using Lucene.Net.QueryParsers;
using Lucene.Net.Search;
using Lucene.Net.Store;

namespace UniSearchSystem
{
    class MantSearch
    {
        const Lucene.Net.Util.Version VERSION = Lucene.Net.Util.Version.LUCENE_30;

        string indexPath;
        Analyzer analyzer;

        public MantSearch(string indexPath, Analyzer analyzer)
        {
            this.indexPath = indexPath;
            this.analyzer = analyzer;
        }

        public List<Dictionary<string, string>> search(string queryText)
        {
            Directory indexDirectory = FSDirectory.Open(indexPath);
            IndexSearcher searcher = new IndexSearcher(indexDirectory);

            QueryParser queryParser = new QueryParser(VERSION, "text", analyzer);
            Query query = queryParser.Parse(queryText.ToLower());

            TopDocs topDocs = searcher.Search(query, 100);

            List<Dictionary<string,string>> searchResult = new List<Dictionary<string, string>>();
            int rank = 0;
            foreach (ScoreDoc scoreDoc in topDocs.ScoreDocs)
            {
                rank++;
                Document doc = searcher.Doc(scoreDoc.Doc);
                string textField = doc.Get("text").ToString();
                string urlField = doc.Get("url").ToString();

                Dictionary<string, string> dict = new Dictionary<string, string>();
                dict.Add("text", textField);
                dict.Add("url", urlField);
                dict.Add("rank", rank.ToString());

                searchResult.Add(dict);
            }

            searcher.Dispose();

            return searchResult;
        }

    }
}
