﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UniSearchSystem
{
    class Passeges
    {

        public string query_id { get; set; }

        public string[] passages { get; set; }
        public string answers { get; set; }
        public string query_type { get; set; }
        public string query { get; set; }

    }
}
