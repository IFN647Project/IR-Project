﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UniSearchSystem
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new MANTForm());

            //Lucene.Net.Analysis.Analyzer simpleAnalyzer = new Lucene.Net.Analysis.SimpleAnalyzer();
            //LuceneAdvancedSearchApplication advancedSearchAppplication = new LuceneAdvancedSearchApplication(simpleAnalyzer);

            //parser = new QueryParser(Lucene.Net.Util.Version.LUCENE_30, TEXT_FN, analyzer);

            //Application.Run(new MANTForm());
        }
    }
}
