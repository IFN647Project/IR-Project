﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lucene.Net.Analysis; // for Analyser
using Lucene.Net.Documents; // for Document and Field
using Lucene.Net.Index; //for Index Writer
using Lucene.Net.Store; //for Directory
using Lucene.Net.Search; // for IndexSearcher
using Lucene.Net.QueryParsers;  // for QueryParser   
using Lucene.Net.Analysis.Snowball;// for snowball analyser
using System.IO;
using System.Net;
using Newtonsoft.Json;
using System.Diagnostics;
using Syn.WordNet;

namespace singlepagebaseline
{
    public partial class Form1 : Form
    {
        string indexPath;
        string tosearch;
        List<string> result;
        
        string filePath;
        Lucene.Net.Store.Directory luceneIndexDirectory;
        Lucene.Net.Analysis.Analyzer analyzer;
        Lucene.Net.Index.IndexWriter writer;
        IndexSearcher searcher;
        QueryParser parser;
        stopword s1;
        // Similarity newSimilarity;// Activity 9
        
        const Lucene.Net.Util.Version VERSION = Lucene.Net.Util.Version.LUCENE_30;
        const string TEXT_FN = "Text";
        public Form1()
        {
            InitializeComponent();
            result = new List<string>();
            s1 = new stopword();
            
            luceneIndexDirectory = null;
            writer = null;

            analyzer = new Lucene.Net.Analysis.SimpleAnalyzer();

            parser = new QueryParser(Lucene.Net.Util.Version.LUCENE_30, TEXT_FN, analyzer);


        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            tosearch = textBox1.Text;
        }

        private void collection_path_Click(object sender, EventArgs e)
        {

        }

        private void index_path_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void index_save_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            index_path.Text = folderBrowserDialog1.SelectedPath;
            string addindex = "\\index";
            indexPath = folderBrowserDialog1.SelectedPath + addindex;
            
        }

        private void collection_saved_path_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            collection_path.Text = openFileDialog1.FileName;
            filePath = openFileDialog1.FileName;
        }

        private void searchbutton_Click(object sender, EventArgs e)
        {
            
            Stopwatch sw = Stopwatch.StartNew();
            result = SearchText(tosearch);
            sw.Stop();
            var timetaken = sw.Elapsed.Seconds;
            MessageBox.Show("Time taken to search in seconds" + timetaken.ToString());
            MessageBox.Show("text searched");
            listBox1.DataSource = result;
            
            CleanUpIndexer();

            CleanUpSearcher();

        }

        private void create_index_button_Click(object sender, EventArgs e)
        {
            Stopwatch sw = Stopwatch.StartNew();
            CreateIndex(indexPath);
            jsreader(filePath);
            sw.Stop();
            var timetaken = sw.Elapsed.Seconds;
            MessageBox.Show("Time taken in seconds" + timetaken.ToString());
            CreateSearcher();
            MessageBox.Show("index created");
        }
        /////////////////////// code for lucene ////////////////////////////////////////////////////////////////////////////
        public void CreateIndex(string indexPath)
        {
            luceneIndexDirectory = Lucene.Net.Store.FSDirectory.Open(indexPath);
            IndexWriter.MaxFieldLength mfl = new IndexWriter.MaxFieldLength(IndexWriter.DEFAULT_MAX_FIELD_LENGTH);
            writer = new Lucene.Net.Index.IndexWriter(luceneIndexDirectory, analyzer, true, mfl);

        }


        /// <summary>
        /// Indexes a given string into the index
        /// </summary>
        /// <param name="text">The text to index</param>
        public void IndexText(string text)
        {

            Lucene.Net.Documents.Field field = new Field(TEXT_FN, text, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.YES);
            Lucene.Net.Documents.Document doc = new Document();
            doc.Add(field);
            writer.AddDocument(doc);
        }

        /// <summary>
        /// Flushes the buffer and closes the index
        /// </summary>
        public void CleanUpIndexer()
        {
            writer.Optimize();
            writer.Flush(true, true, true);
            writer.Dispose();
        }


        /// <summary>
        /// Creates the searcher object
        /// </summary>
        public void CreateSearcher()
        {
            searcher = new IndexSearcher(luceneIndexDirectory);

        }

        /// <summary>
        /// Searches the index for the querytext
        /// </summary>
        /// <param name="querytext">The text to search the index</param>
        public List<string> SearchText(string querytext)
        {
            
            //System.Console.WriteLine("Searching for " + querytext);
            querytext = querytext.ToLower();
            Query query = parser.Parse(querytext);
            TopDocs results = searcher.Search(query, 100);
            // System.Console.WriteLine("Number of results is " + results.TotalHits);
            int rank = 0;
           List<string> result1 = new List<string>();
            foreach (ScoreDoc scoreDoc in results.ScoreDocs)
            {
                rank++;
                Lucene.Net.Documents.Document doc = searcher.Doc(scoreDoc.Doc);
                string myFieldValue = doc.Get(TEXT_FN).ToString();

                result1.Add("Rank " + rank + " text " + myFieldValue);
            }

            return result1;
        }

        /// <summary>
        /// Closes the index after searching
        /// </summary>
        public void CleanUpSearcher()
        {
            searcher.Dispose();
        }

        public void jsreader(string filePath)
        {
            StreamReader streamReader = new StreamReader(filePath);
            JsonTextReader JTextreader = new JsonTextReader(streamReader);

            JTextreader.SupportMultipleContent = true;

            var serializer = new JsonSerializer();
            while (JTextreader.Read())
            {
                if (JTextreader.TokenType == JsonToken.StartObject)
                {
                    RootObject p = serializer.Deserialize<RootObject>(JTextreader);




                    foreach (var para in p.passages)
                    {
                        //passage p_content = serializer.Deserialize<passage>(JTextreader);
                        string s = para.url + para.passage_text;
                        IndexText(s);
                    }

                }
            }
        }
        public static List<string> getonlywords(List<SynSet> collection, string word)
        {
            word = word.ToLower();
            List<string> wordlist = new List<string>();
            List<string> finalwordlist = new List<string>();
            foreach (var item in collection)
            {
                string s = Convert.ToString(item);
                wordlist.Add(wordselector(s, word));
            }
            foreach (string item in wordlist)
            {
                string[] s = item.Split();
                foreach (string i in s)
                {
                    if ((i.Length > 1) && (i.ToLower()) != word)
                    {
                        finalwordlist.Add(i);
                    }
                }
            }

            return finalwordlist;
        }
        /// <summary>
        /// this will take a sentence and fetch only synonyms and related words to the query term
        /// </summary>
        /// <param name="item"></param>
        /// <param name="orignal_word"></param>
        /// <returns></returns>
        public static string wordselector(string item, string orignal_word)
        {
            string wordstring = "";
            bool controller = false;
            string[] seprator = new string[] { " ", ",", ":", ";" };
            string[] words = item.Split(seprator, StringSplitOptions.RemoveEmptyEntries);
            foreach (string a in words)
            {
                string c = "";
                string b = a;
                int countofstring = 0;
                countofstring = b.Length - 1;
                if (b == "{" || b[0] == '{')
                {
                    b = b.Remove(0, 1);
                    controller = true;
                    c = b;
                    int countofc = c.Length;
                    if (c[(countofc - 1)] == '}')
                    {
                        c = c.Remove((countofc - 1), 1);
                    }
                }

                if (controller == true && (b != orignal_word) && (c != orignal_word))
                {
                    if (b[(b.Length - 1)] == '}')
                    {
                        wordstring += " " + b.Remove((b.Length - 1), 1);
                        controller = false;
                    }
                    else
                    {
                        wordstring += " " + b;
                    }


                }

                int countofstring1 = 0;
                countofstring1 = b.Length - 1;

                if (b == "}" || b[countofstring1] == '}')
                {

                    controller = false;
                }

            }
            return wordstring;
        }
        //////////////////////////// end code for lucene////////////////////////////////////////////////////////////
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void domainUpDown1_SelectedItemChanged(object sender, EventArgs e)
        {
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            var item = this.comboBox1.GetItemText(this.comboBox1.SelectedItem);
            MessageBox.Show(item);
            if (item == "simple")
            {
                analyzer = new Lucene.Net.Analysis.SimpleAnalyzer();
            }
            else if (item == "whitespace")
            {
                analyzer = new Lucene.Net.Analysis.WhitespaceAnalyzer();
            }
            else if (item == "standard")
            {
                analyzer = new Lucene.Net.Analysis.Standard.StandardAnalyzer(Lucene.Net.Util.Version.LUCENE_30);
            }
            else if (item == "stopanalyzer")
            {
                analyzer = new Lucene.Net.Analysis.StopAnalyzer(VERSION);
            }
            else if (item == "snowball")
            {
                analyzer = new Lucene.Net.Analysis.Snowball.SnowballAnalyzer(Lucene.Net.Util.Version.LUCENE_30, "English");
            }
            else
            {
                MessageBox.Show("please give a valid selection");
            }




        }
    }

}
