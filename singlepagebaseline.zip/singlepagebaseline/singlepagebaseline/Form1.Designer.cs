﻿namespace singlepagebaseline
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.index_path = new System.Windows.Forms.Label();
            this.collection_path = new System.Windows.Forms.Label();
            this.index_save = new System.Windows.Forms.Button();
            this.collection_saved_path = new System.Windows.Forms.Button();
            this.create_index_button = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.searchbutton = new System.Windows.Forms.Button();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // index_path
            // 
            this.index_path.AutoSize = true;
            this.index_path.Location = new System.Drawing.Point(26, 20);
            this.index_path.Name = "index_path";
            this.index_path.Size = new System.Drawing.Size(58, 13);
            this.index_path.TabIndex = 1;
            this.index_path.Text = "Index Path";
            this.index_path.Click += new System.EventHandler(this.index_path_Click);
            // 
            // collection_path
            // 
            this.collection_path.AutoSize = true;
            this.collection_path.Location = new System.Drawing.Point(26, 44);
            this.collection_path.Name = "collection_path";
            this.collection_path.Size = new System.Drawing.Size(78, 13);
            this.collection_path.TabIndex = 2;
            this.collection_path.Text = "Collection Path";
            this.collection_path.Click += new System.EventHandler(this.collection_path_Click);
            // 
            // index_save
            // 
            this.index_save.Location = new System.Drawing.Point(301, 10);
            this.index_save.Name = "index_save";
            this.index_save.Size = new System.Drawing.Size(53, 23);
            this.index_save.TabIndex = 3;
            this.index_save.Text = "Save";
            this.index_save.UseVisualStyleBackColor = true;
            this.index_save.Click += new System.EventHandler(this.index_save_Click);
            // 
            // collection_saved_path
            // 
            this.collection_saved_path.Location = new System.Drawing.Point(301, 34);
            this.collection_saved_path.Name = "collection_saved_path";
            this.collection_saved_path.Size = new System.Drawing.Size(53, 23);
            this.collection_saved_path.TabIndex = 4;
            this.collection_saved_path.Text = "Browse";
            this.collection_saved_path.UseVisualStyleBackColor = true;
            this.collection_saved_path.Click += new System.EventHandler(this.collection_saved_path_Click);
            // 
            // create_index_button
            // 
            this.create_index_button.Location = new System.Drawing.Point(360, 12);
            this.create_index_button.Name = "create_index_button";
            this.create_index_button.Size = new System.Drawing.Size(61, 45);
            this.create_index_button.TabIndex = 5;
            this.create_index_button.Text = "Create Index";
            this.create_index_button.UseVisualStyleBackColor = true;
            this.create_index_button.Click += new System.EventHandler(this.create_index_button_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(427, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(291, 20);
            this.textBox1.TabIndex = 6;
            this.textBox1.Text = "enter text to search";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // searchbutton
            // 
            this.searchbutton.Location = new System.Drawing.Point(724, 9);
            this.searchbutton.Name = "searchbutton";
            this.searchbutton.Size = new System.Drawing.Size(75, 23);
            this.searchbutton.TabIndex = 7;
            this.searchbutton.Text = "Search";
            this.searchbutton.UseVisualStyleBackColor = true;
            this.searchbutton.Click += new System.EventHandler(this.searchbutton_Click);
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "myOpenFileDialog";
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(88, 113);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(624, 225);
            this.listBox1.TabIndex = 8;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.searchbutton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.searchbutton);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.create_index_button);
            this.Controls.Add(this.collection_saved_path);
            this.Controls.Add(this.index_save);
            this.Controls.Add(this.collection_path);
            this.Controls.Add(this.index_path);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label index_path;
        private System.Windows.Forms.Label collection_path;
        private System.Windows.Forms.Button index_save;
        private System.Windows.Forms.Button collection_saved_path;
        private System.Windows.Forms.Button create_index_button;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button searchbutton;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.ListBox listBox1;
    }
}

