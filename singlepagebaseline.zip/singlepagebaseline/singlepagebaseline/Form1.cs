﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lucene.Net.Analysis; // for Analyser
using Lucene.Net.Documents; // for Document and Field
using Lucene.Net.Index; //for Index Writer
using Lucene.Net.Store; //for Directory
using Lucene.Net.Search; // for IndexSearcher
using Lucene.Net.QueryParsers;  // for QueryParser   
using Lucene.Net.Analysis.Snowball;// for snowball analyser
using System.IO;
using System.Net;
using Newtonsoft.Json;
using System.Diagnostics;
using Syn.WordNet;

namespace singlepagebaseline
{
    public partial class Form1 : Form
    {
        public static string indexPath="";
        public static string tosearch="";
        List<string> result =  new List<string>();
        
        public static string filePath ="";
        public static Lucene.Net.Store.Directory luceneIndexDirectory = null;
        public static Lucene.Net.Analysis.Analyzer analyzer = new Lucene.Net.Analysis.SimpleAnalyzer();
        public static Lucene.Net.Index.IndexWriter writer = null;
        IndexSearcher searcher;
        QueryParser parser = new QueryParser(Lucene.Net.Util.Version.LUCENE_30, TEXT_FN, analyzer);
        stopword s1;
        // Similarity newSimilarity;// Activity 9
        
        const Lucene.Net.Util.Version VERSION = Lucene.Net.Util.Version.LUCENE_30;
        const string TEXT_FN = "Text";
        public Form1()
        {
            InitializeComponent();
           

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            tosearch = textBox1.Text;
        }

        private void collection_path_Click(object sender, EventArgs e)
        {

        }

        private void index_path_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void index_save_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            index_path.Text = folderBrowserDialog1.SelectedPath;
            string addindex = "\\index";
            indexPath = folderBrowserDialog1.SelectedPath + addindex;
            
        }

        private void collection_saved_path_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            collection_path.Text = openFileDialog1.FileName;
            filePath = openFileDialog1.FileName;
        }

        private void searchbutton_Click(object sender, EventArgs e)
        {
            
            Stopwatch sw = Stopwatch.StartNew();
            CreateSearcher();
            result = SearchText(tosearch);
            sw.Stop();
            var timetaken = sw.Elapsed.Seconds;
            var min = sw.Elapsed.Minutes;
            MessageBox.Show("Time taken to search in seconds" + min.ToString()+ ":" +timetaken.ToString());
            listBox1.DataSource = result;
            
      
        }

        private void create_index_button_Click(object sender, EventArgs e)
        {
            Stopwatch sw = Stopwatch.StartNew();
            jsreader(indexPath,filePath);
            sw.Stop();
            var m = sw.Elapsed.Minutes;
            var s = sw.Elapsed.Seconds;
            MessageBox.Show("Time taken in seconds" + m.ToString() +":" + s);
           
            CleanUpIndexer();
        }
        /////////////////////// code for lucene ////////////////////////////////////////////////////////////////////////////
        


        /// <summary>
        /// Indexes a given string into the index
        /// </summary>
        /// <param name="text">The text to index</param>
        public void IndexText(string text)
        {

            Lucene.Net.Documents.Field field = new Field(TEXT_FN, text, Field.Store.YES, Field.Index.ANALYZED, Field.TermVector.YES);
            Lucene.Net.Documents.Document doc = new Document();
            doc.Add(field);
            writer.AddDocument(doc);
        }

        /// <summary>
        /// Flushes the buffer and closes the index
        /// </summary>
        public void CleanUpIndexer()
        {
            writer.Optimize();
            writer.Flush(true, true, true);
            writer.Dispose();
        }


        /// <summary>
        /// Creates the searcher object
        /// </summary>
        public void CreateSearcher()
        {
            searcher = new IndexSearcher(luceneIndexDirectory);

        }

        /// <summary>
        /// Searches the index for the querytext
        /// </summary>
        /// <param name="querytext">The text to search the index</param>
        public List<string> SearchText(string querytext)
        {
            
            //System.Console.WriteLine("Searching for " + querytext);
            querytext = querytext.ToLower();
            Query query = parser.Parse(querytext);
            TopDocs results = searcher.Search(query, 100);
            // System.Console.WriteLine("Number of results is " + results.TotalHits);
            int rank = 0;
           List<string> result1 = new List<string>();
            foreach (ScoreDoc scoreDoc in results.ScoreDocs)
            {
                rank++;
                Lucene.Net.Documents.Document doc = searcher.Doc(scoreDoc.Doc);
                string myFieldValue = doc.Get(TEXT_FN).ToString();

                result1.Add("Rank " + rank + " text " + myFieldValue);
            }

            return result1;
        }

        /// <summary>
        /// Closes the index after searching
        /// </summary>
        public void CleanUpSearcher()
        {
            searcher.Dispose();
        }

        public void jsreader(string indexpath , string filePath)
        {
            luceneIndexDirectory = Lucene.Net.Store.FSDirectory.Open(indexPath);
            IndexWriter.MaxFieldLength mfl = new IndexWriter.MaxFieldLength(IndexWriter.DEFAULT_MAX_FIELD_LENGTH);
            writer = new Lucene.Net.Index.IndexWriter(luceneIndexDirectory, analyzer, true, mfl);

            StreamReader streamReader = new StreamReader(filePath);
            JsonTextReader JTextreader = new JsonTextReader(streamReader);

            JTextreader.SupportMultipleContent = true;

            var serializer = new JsonSerializer();
            while (JTextreader.Read())
            {
                if (JTextreader.TokenType == JsonToken.StartObject)
                {
                    RootObject p = serializer.Deserialize<RootObject>(JTextreader);




                    foreach (var para in p.passages)
                    {
                        //passage p_content = serializer.Deserialize<passage>(JTextreader);
                        string s = para.url + para.passage_text;
                        IndexText(s);
                    }

                }
            }
        }
        
        //////////////////////////// end code for lucene////////////////////////////////////////////////////////////
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void domainUpDown1_SelectedItemChanged(object sender, EventArgs e)
        {
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            CleanUpSearcher();
            this.Close();
        }
    }

}
