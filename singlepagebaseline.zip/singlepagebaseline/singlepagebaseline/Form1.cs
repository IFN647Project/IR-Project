﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace singlepagebaseline
{
    public partial class Form1 : Form
    {
        string indexPath;
        string tosearch;
        List<string> result;
        LuceneAdvancedSearchApplication myLuceneApp;
        string filePath;
        public Form1()
        {
            InitializeComponent();
            result = new List<string>();
            myLuceneApp = new LuceneAdvancedSearchApplication();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            tosearch = textBox1.Text;
        }

        private void collection_path_Click(object sender, EventArgs e)
        {

        }

        private void index_path_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            listBox1.DataSource = result;
            myLuceneApp.CleanUpIndexer();

            myLuceneApp.CleanUpSearcher();
        }

        private void index_save_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            index_path.Text = folderBrowserDialog1.SelectedPath;
            string addindex = "\\index";
            indexPath = folderBrowserDialog1.SelectedPath + addindex;
            
        }

        private void collection_saved_path_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            collection_path.Text = openFileDialog1.FileName;
            filePath = openFileDialog1.FileName;
        }

        private void searchbutton_Click(object sender, EventArgs e)
        {
            result = myLuceneApp.SearchText(tosearch);
        }

        private void create_index_button_Click(object sender, EventArgs e)
        {  
            myLuceneApp.CreateIndex(indexPath);
            myLuceneApp.jsreader(filePath);
            myLuceneApp.CreateSearcher();
            MessageBox.Show("index created");
        }
    }
}
